﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.고속세기
{
    public partial class 고속세기진행 : Form
    {
        int mSec = 0;

        public 고속세기진행()
        {
            InitializeComponent();

            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            this.Hide();
            new 고속세기완료(mSec).ShowDialog();
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mSec++;
        }
    }
}
