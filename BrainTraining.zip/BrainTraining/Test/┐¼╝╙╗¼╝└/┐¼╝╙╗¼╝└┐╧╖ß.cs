﻿using BrainTraining.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.연속뺄셈
{
    public partial class 연속뺄셈완료 : Form
    {
        RealModeRecord test;
        public 연속뺄셈완료(int mSec)
        {
            InitializeComponent();
            로그인.record = new DataManager().LoadRecord();
            if (로그인.record.연속뺄셈 == 0) // 오늘 처음 테스트 할때만
            {
                로그인.record.연속뺄셈 = mSec;
                new DataManager().SaveRecord();
            }
            RecordCalculate rc = new RecordCalculate();
            int age = rc.연속뺄셈나이(mSec);
            string time = rc.GetCalculatedTime(mSec);
            label1.Text = time + "초로 " + age + "세 수준입니다.";
            if (실전모드.realMode == true)
            {
                test = new RealModeRecord("연속뺄셈", time, age);
            }
            List<string> data1 = new DataManager().개인베스트5("연속뺄셈");
            dataGridView1.DataSource = data1.Select(p => new { record = p }).ToList(); ;

            List<UserBest5> data2 = new DataManager().유저베스트5("연속뺄셈");
            dataGridView2.DataSource = data2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (실전모드.realMode == true)
            {
                실전모드.realModeRecords.Add(test);
                this.Hide();
                new 실전모드결과().ShowDialog();
                Application.Exit();
            }
            else
            {
                this.Hide();
                new 선택모드().ShowDialog();
                Application.Exit();
            }
        }
    }
}
