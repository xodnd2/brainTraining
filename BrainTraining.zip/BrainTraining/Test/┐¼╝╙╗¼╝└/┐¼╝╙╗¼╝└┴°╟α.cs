﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.연속뺄셈
{
    public partial class 연속뺄셈진행 : Form
    {
        Random rand = new Random();
        int curNum;
        int nextNum;
        int minusNum;
        int mSec;
        int mSecForHide;
        
        public 연속뺄셈진행()
        {
            InitializeComponent();
            this.ActiveControl = textBox1;
            timer1.Start();

            curNum = rand.Next(67, 107);
            if(curNum > 66 && curNum < 75)
            {
                minusNum = 6;
            } 
            else if(curNum > 74 && curNum < 90)
            {
                minusNum = 7;
            }
            else if (curNum > 89 && curNum < 100)
            {
                minusNum = 8;
            }
            else
            {
                minusNum = 9;
            }
            nextNum = curNum - minusNum;

            label1.Text = curNum.ToString();
            label2.Text = minusNum.ToString();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == nextNum.ToString())
            {
                curNum = nextNum;
                nextNum = curNum - minusNum;
                if(nextNum < 0)
                {
                    timer1.Stop();
                    this.Hide();
                    new 연속뺄셈완료(mSec).ShowDialog();
                    Application.Exit();
                }
                label1.Text = curNum.ToString();
                label1.BackColor = Color.White;
                textBox1.Text = "";

                timer2.Start();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (label1.BackColor == Color.Black)
            {
                curNum += minusNum;
                nextNum += minusNum;
                label1.Text = curNum.ToString();
                label1.BackColor = Color.White;
                timer2.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mSec++;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            mSecForHide++;
            if (mSecForHide == 30)
            {
                timer2.Stop();
                mSecForHide = 0;
                label1.BackColor = Color.Black;
            }
        }
    }
}
