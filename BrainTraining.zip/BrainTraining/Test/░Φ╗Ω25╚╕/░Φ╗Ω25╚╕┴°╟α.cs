﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.계산25회
{
    

    public partial class 계산25회진행 : Form
    {  
        Random rand = new Random();
        int mSec = 0;
        int cnt = 0;
        int answerNow = 0;
        int answerNext = 0;

        public 계산25회진행()
        {
            InitializeComponent();
            this.ActiveControl = textBox1;
            label3.Text = "";
            timer1.Start();

            answerNow = MakeExpAndGetAnswer(true);
            answerNext = MakeExpAndGetAnswer(false);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mSec++;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            this.Hide();
            new 계산25회완료(mSec).ShowDialog();
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == answerNow.ToString())
            {
                cnt++;
                if (cnt == 25)
                {
                    timer1.Stop();
                    this.Hide();
                    new 계산25회완료(mSec).ShowDialog();
                    Application.Exit();
                }
                textBox1.Text = "";
                textBox1.Focus();
                answerNow = answerNext;
                label1.Text = label2.Text;
                answerNext = MakeExpAndGetAnswer(false);
                label3.Text = "정답";
            }
            else
            {
                label3.Text = "오답";
            }           
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button2_Click(sender, e);               
            }                
        }

        int MakeExpAndGetAnswer(bool now)
        {
            int op;
            int left;
            int right;
            int answer = 0;
            string exp;
            op = rand.Next(1, 4);
            switch (op)
            {
                case 1: // +
                    left = rand.Next(0, 18);
                    right = rand.Next(0, 18);
                    answer = left + right;
                    exp = left.ToString() + " + " + right.ToString();
                    if (now)
                        label1.Text = exp;
                    else
                        label2.Text = exp;
                    break;
                case 2: // -
                    left = rand.Next(0, 18);
                    right = rand.Next(0, 18);
                    if (left < right)
                    {
                        int temp = left;
                        left = right;
                        right = temp;
                    }
                    answer = left - right;
                    exp = left.ToString() + " - " + right.ToString();
                    if (now)
                        label1.Text = exp;
                    else
                        label2.Text = exp;
                    break;
                case 3: // *
                    left = rand.Next(0, 10);
                    right = rand.Next(0, 10);
                    answer = left * right;
                    exp = left.ToString() + " x " + right.ToString();
                    if (now)
                        label1.Text = exp;
                    else
                        label2.Text = exp;
                    break;
            }
            return answer;
        }
    }
}
