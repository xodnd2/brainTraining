﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 최고숫자진행 : Form
    {
        public 최고숫자진행()
        {
            InitializeComponent();
        }
    }
}
