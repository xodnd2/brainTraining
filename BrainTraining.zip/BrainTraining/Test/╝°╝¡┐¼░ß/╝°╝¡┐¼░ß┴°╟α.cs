﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.순서연결
{
    public partial class 순서연결진행 : Form
    {
        Random rand = new Random();
        List<int> nums = new List<int>();
        int num;
        int cnt;
        string labelName;
        int mSec;

        public 순서연결진행()
        {
            InitializeComponent();
            makeGame();
            timer1.Start();
            for (int i = 1; i <= 26; i++) // 순서체크
            {
                labelName = "label" + i;
                Label label = (Label)Controls[labelName];
                label.Click += (sender, e) =>
                {
                    if (cnt == 25) // 완료
                    {
                        timer1.Stop();
                        this.Hide();
                        new 순서연결완료(mSec).ShowDialog();
                        Application.Exit();
                    }

                    if (cnt % 2 == 0) // 알파벳
                    {
                        if (label.Name == "label" + nums[cnt/2])
                        {
                            cnt++;
                            label.BackColor = Color.Green;
                        }
                    }
                    else // 숫자
                    {
                        if (label.Name == "label" + nums[13 + cnt/2])
                        {
                            cnt++;
                            label.BackColor = Color.Green;
                        }
                    }
                };
            }
        }

        void makeGame()
        {
            for (int i = 1; i <= 26; i++)
            {
                do
                {
                    num = rand.Next(1, 27);
                } while (nums.Contains(num));
                nums.Add(num);
                labelName = "label" + num;
                Label randomLabel = (Label)Controls[labelName];
                if (i <= 13)
                    randomLabel.Text = ((char)(64 + i)).ToString();
                else
                    randomLabel.Text = (i-13).ToString();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mSec++;
        }
    }
}
