﻿using BrainTraining.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.기억5X5
{
    public partial class 기억5X5진행 : Form
    {
        int mSec = 7200;
        int num = 0;
        int answerCnt = 0;
        int level = 0;
        List<int> nums = new List<int>();
        

        public 기억5X5진행()
        {
            InitializeComponent();
            timer1.Start();
            
            for (int i = 0; i < 25; i++)
            {
                do
                {
                    num = new Random().Next(1, 26);
                } while (nums.Contains(num));
                nums.Add(num);
            }

            for (int i = 1; i <= 25; i++)
            {
                string name = "textbox" + i;
                TextBox box = (TextBox)Controls[name];
                box.Text = nums[i - 1].ToString();
                box.ReadOnly = true;
            }
         
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mSec--;
            string timeLeft = new RecordCalculate().GetCalculatedTime(mSec,1);
            label1.Text = "남은 시간: " + timeLeft;

            if (mSec == 0)
            {
                button1_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(level == 0)
            {
                level++;
                for (int i = 1; i <= 25; i++)
                {
                    string name = "textbox" + i;
                    TextBox box = (TextBox)Controls[name];
                    box.Text = "";
                    box.ReadOnly = false;
                }
                mSec = 7200;
                
                button1.Text = "제출";
            }
            else if (level == 1)
            {
                level++;                
                for (int i = 1; i <= 25; i++)
                {
                    string name = "textbox" + i;
                    TextBox box = (TextBox)Controls[name];
                    box.ReadOnly = true;
                    if (box.Text == nums[i - 1].ToString())
                    {
                        answerCnt++;
                        box.BackColor = Color.Green;
                    }
                    else
                    {
                        box.BackColor = Color.Red;
                        box.Text = nums[i - 1].ToString();
                    }
                }
                timer1.Stop();
                label1.Text = "맞은 개수: " + answerCnt + "/25";
                button1.Text = "확인";
            }
            else if (level == 2)
            {         
                this.Hide();
                new 기억5X5완료(answerCnt).ShowDialog();
                Application.Exit();
            }
        }
    }
}
