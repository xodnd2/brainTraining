﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining.Test.가위바위보
{
    public partial class 가위바위보진행 : Form
    {
        Random rand = new Random();
        int winOrLose;
        int picNum;
        int answer;
        int myAnswer;
        int cnt;
        int mSec;
        string picLink;

        public 가위바위보진행()
        {
            InitializeComponent();
            가위바위보생성();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mSec++;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            myAnswer = 1;
            OnClick();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            myAnswer = 2;
            OnClick();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            myAnswer = 3;
            OnClick();
        }

        void 가위바위보생성()
        {
            picNum = rand.Next(1, 4);
            winOrLose = rand.Next(1, 3);
            picLink = "C:\\Users\\강태웅\\source\\repos\\BrainTraining\\BrainTraining\\Test\\가위바위보\\" + picNum + ".jpg";
            pictureBox4.Load(picLink);

            if (winOrLose == 1)
            {
                label1.Text = "이겨주십시오.";
                switch (picNum)
                {
                    case 1:
                        answer = 2;
                        break;
                    case 2:
                        answer = 3;
                        break;
                    case 3:
                        answer = 1;
                        break;
                }
            }
            else if (winOrLose == 2)
            {
                label1.Text = "져 주십시오.";
                switch (picNum)
                {
                    case 1:
                        answer = 3;
                        break;
                    case 2:
                        answer = 1;
                        break;
                    case 3:
                        answer = 2;
                        break;
                }
            }
        }

        void OnClick()
        {
            if (myAnswer == answer)
            {
                myAnswer = 0;
                cnt++;
                if (cnt != 20)
                    가위바위보생성();
                else
                {
                    timer1.Stop();
                    this.Hide();
                    new 가위바위보완료(mSec).ShowDialog();
                    Application.Exit();
                }
            }
        }

    }
}
