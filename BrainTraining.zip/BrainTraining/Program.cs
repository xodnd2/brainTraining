﻿using BrainTraining.Test.가위바위보;
using BrainTraining.Test.기억5X5;
using BrainTraining.Test.순서연결;
using BrainTraining.Test.연속뺄셈;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    static class Program
    {
        /// <summary>
        /// 해당 애플리케이션의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new 로그인());
        }
    }
}
