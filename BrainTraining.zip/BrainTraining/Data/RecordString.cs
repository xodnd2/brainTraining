﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrainTraining.Data
{
    public class RecordString
    {
        public string id { get; set; }
        public string date { get; set; }
        public int brainAge { get; set; }
        public string 순서연결 { get; set; }
        public string 가위바위보 { get; set; }
        public string 계산25회 { get; set; }
        public string 고속세기 { get; set; }
        public int 기억5X5 { get; set; }
        public string 연속뺄셈 { get; set; }
    }
}
