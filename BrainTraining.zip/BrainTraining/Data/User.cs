﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrainTraining.Data
{
    public class User
    {
        public string id { get; set; }
        public string pwd { get; set; }
        public string birth { get; set; }
        public int bestBrain { get; set; }
        public int curBrain { get; set; }
        public string curBrainDate { get; set; }
        public string curLoginDate { get; set; }
    }
}
