﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrainTraining.Data
{
    class RecordCalculate
    {
        public int 순서연결나이(int mSec)
        {
            int age = 20;
            if (mSec <= 2880) return age;

            if(mSec > 2880 && mSec <= 3600)
            {
                int plus = (mSec - 2880) / 36;
                age += plus;
            }
            else if (mSec > 3600 && mSec <= 4800)
            {
                age = 40;
                int plus = (mSec - 3600) / 60;
                age += plus;
            }
            else if (mSec > 4800 && mSec <= 6000)
            {
                age = 60;
                int plus = (mSec - 4800) / 120;
                age += plus;
            }
            else if (mSec > 6000 && mSec <= 6600)
            {
                age = 70;
                int plus = (mSec - 6000) / 60;
                age += plus;
            }
            else
            {
                age = 80;
            }

            return age;
        }

        public int 연속뺄셈나이(int mSec)
        {
            int age = 20;
            if (mSec <= 1560) return age;

            int plus = (mSec - 1560) / 21;
            if (plus >= 60) age = 80;
            else age += plus;

            return age;
        }

        public int 가위바위보나이(int mSec)
        {
            int age = 20;
            if (mSec <= 1920) return age;

            int plus = (mSec - 1920) / 24;
            if (plus >= 60) age = 80;
            else age += plus; 

            return age;
        }

        public int 고속세기나이(int mSec)
        {
            int age = 20;
            if (mSec <= 2520) return age;

            int plus = (mSec - 2520) / 15;
            if (plus >= 60) age = 80;
            else age += plus;

            return age;
        }

        public int 계산25회나이(int mSec)
        {
            int age = 20;
            if (mSec <= 1440) return age;

            int plus = (mSec - 1440) / 24;
            if (plus >= 60) age = 80;
            else age += plus;

            return age;
        }

        public int 기억5X5나이(int answerCnt)
        {
            int age = 20;
            if (answerCnt < 8) age = 80;
            else if (answerCnt > 17) age = 20;
            else if(answerCnt == 17) age = 23;
            else if (answerCnt == 16) age = 26;
            else
            {
                age = 30;
                for (int i = 15; answerCnt != i; i--)
                {
                    age += 6;
                }
            }

            return age;
        }

        public string GetCalculatedTime(int mSec, int exceptMSec = 0)
        {
            int min;
            int sec;
            string record;

            min = mSec / 3600;
            sec = (mSec % 3600) / 60;
            mSec = mSec % 60;
            record = min + ":" + sec + ":" + mSec;
            if (exceptMSec == 1)
            {
                record = min + ":" + sec;
                return record;
            }
            return record;
        }
    }
}
