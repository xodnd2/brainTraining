﻿using BrainTraining.Data;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BrainTraining
{
    class DataManager
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=brain;Uid=root;Pwd=1234;");

        public DataManager()
        {
            connection.Open();
        } 

        ~DataManager()
        {
            connection.Close();
        }

        public string Login(string id, string pwd)
        {
            try
            {
                string query = "select id from user where(id = '" + id + "' and pwd = '" + pwd + "');";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataReader reader = command.ExecuteReader();
                reader.Read();
                string rId = reader[0].ToString();

                reader.Close();
                return rId;
            } catch(Exception e)
            {
                return "";
            } 
        }

        public void Register(string id, string pwd, string birth)
        {
            string query1 = "insert into user(id,pwd,birth) values('" + id + "','" + pwd + "', '" + birth + "');";            
            MySqlCommand command = new MySqlCommand(query1, connection);
            command.ExecuteNonQuery();
        }

        public User LoadUser()
        {
            User user = new User();

            string query = "select * from user where(id = '" + 로그인.loginID + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            reader.Read();
            user.id = reader[0].ToString();
            user.pwd = reader[1].ToString();
            user.birth = reader[2].ToString().Substring(0,10);
            user.bestBrain = (int)reader[3];
            user.curBrain = (int)reader[4];
            user.curBrainDate = reader[5].ToString().Substring(0, 10);
            user.curLoginDate = reader[6].ToString().Substring(0, 10);
            reader.Close();
            return user;
        }

        public void SaveUser()
        {
            string query =
                "update user set    pwd = '" + 로그인.user.pwd + "'"
                + ", birth = '" + 로그인.user.birth + "'"
                + ", bestbrain = " + 로그인.user.bestBrain
                + ", curbrain = " + 로그인.user.curBrain
                + ", curbraindate = '" + 로그인.user.curBrainDate + "'"
                + ", curlogindate = '" + 로그인.user.curLoginDate + "'"
                + " where id = '" + 로그인.loginID + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
        }

        public Record LoadRecord()
        {
            Record record = new Record();

            string query = "select * from record where(id = '" + 로그인.loginID + "' and date ='" + 로그인.user.curLoginDate + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            reader.Read();
            record.id = reader[0].ToString();
            record.date = reader[1].ToString().Substring(0, 10);
            record.brainAge = (int)reader[2];
            record.순서연결 = (int)reader[3];
            record.가위바위보 = (int)reader[4];
            record.계산25회 = (int)reader[5];
            record.고속세기 = (int)reader[6];
            record.기억5X5 = (int)reader[7];
            record.연속뺄셈 = (int)reader[8];
            reader.Close();
            return record;
        }

        public void SaveRecord()
        {
            string query =
                "update record set"
                + " brainage = '" + 로그인.record.brainAge + "'"
                + ", 순서연결 = " + 로그인.record.순서연결
                + ", 가위바위보 = " + 로그인.record.가위바위보
                + ", 계산25회 = " + 로그인.record.계산25회
                + ", 고속세기 = " + 로그인.record.고속세기
                + ", 기억5X5 = " + 로그인.record.기억5X5
                + ", 연속뺄셈 = " + 로그인.record.연속뺄셈
                + " where id = '" + 로그인.loginID 
                + "' and date= '" + 로그인.record.date + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
        }

        public void CreateTodayRecord()
        {
            string query = "insert into record(id,date) values('" + 로그인.loginID + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
        }

        public List<string> 개인베스트5(string test)
        {
            List<string> list = new List<string>();            
            string query = "select " + test + " from record where id = '" + 로그인.loginID + "' and "
                + test + " not in (0) order by " + test + " asc limit 5 ;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            while(reader.Read())
            {
                string a;
                if (test != "기억5X5")
                {
                    a = new RecordCalculate().GetCalculatedTime((int)reader[0]);
                }
                else a = reader[0].ToString();
                list.Add(a);
            }
            return list;
        }

        public List<UserBest5> 유저베스트5(string test)
        {
            List<UserBest5> list = new List<UserBest5>();
            string query = "select id," +test + " from record where "
                + test + " not in (0) order by " + test + " asc limit 5 ;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                UserBest5 ub = new UserBest5();
                ub.id = reader[0].ToString();
                if (test != "기억5X5")
                {
                    ub.record = new RecordCalculate().GetCalculatedTime((int)reader[1]);
                }
                else ub.record = reader[1].ToString()+"/25";
                list.Add(ub);
            }
            return list;
        }

        public List<RecordString> LoadAllUser()
        {
            List<RecordString> list = new List<RecordString>();
            string query = "select * from record;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                RecordString record = new RecordString();
                record.id = reader[0].ToString();
                record.date = reader[1].ToString().Substring(0, 10);
                record.brainAge = (int)reader[2];
                record.순서연결 = new RecordCalculate().GetCalculatedTime((int)reader[3]);
                record.가위바위보 = new RecordCalculate().GetCalculatedTime((int)reader[4]);
                record.계산25회 = new RecordCalculate().GetCalculatedTime((int)reader[5]);
                record.고속세기 = new RecordCalculate().GetCalculatedTime((int)reader[6]);
                record.기억5X5 = (int)reader[7];
                record.연속뺄셈 = new RecordCalculate().GetCalculatedTime((int)reader[8]);
                list.Add(record);
            }
            return list;
        }
        public List<RecordString> SearchUser(string id)
        {
            List<RecordString> list = new List<RecordString>();
            string query = "select * from record where id = '"+ id +"';";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                RecordString record = new RecordString();
                record.id = reader[0].ToString();
                record.date = reader[1].ToString().Substring(0, 10);
                record.brainAge = (int)reader[2];
                record.순서연결 = new RecordCalculate().GetCalculatedTime((int)reader[3]);
                record.가위바위보 = new RecordCalculate().GetCalculatedTime((int)reader[4]);
                record.계산25회 = new RecordCalculate().GetCalculatedTime((int)reader[5]);
                record.고속세기 = new RecordCalculate().GetCalculatedTime((int)reader[6]);
                record.기억5X5 = (int)reader[7];
                record.연속뺄셈 = new RecordCalculate().GetCalculatedTime((int)reader[8]);
                list.Add(record);
            }
            return list;
        }
    }
}
