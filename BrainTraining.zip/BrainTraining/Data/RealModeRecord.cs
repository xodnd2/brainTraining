﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrainTraining.Data
{
    public class RealModeRecord
    {
        public RealModeRecord(string testName, string record, int age)
        {
            this.testName = testName;
            this.record = record;
            this.age = age;
        }
        public string testName { get; set; }
        public string record { get; set; }
        public int age { get; set; }
    }
}
