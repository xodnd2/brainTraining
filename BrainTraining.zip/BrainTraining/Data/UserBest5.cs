﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrainTraining
{
    public class UserBest5
    {
        public string id { get; set; }
        public string record { get; set; }
    }
}
