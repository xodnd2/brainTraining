﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace BrainTraining.Data
{
    class MySQLConnect
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=brain;Uid=root;Pwd=1234;");
    }
}
