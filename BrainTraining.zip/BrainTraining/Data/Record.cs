﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrainTraining
{
    public class Record
    {
        public string id { get; set; }
        public string date { get; set; }
        public int brainAge { get; set; }
        public int 순서연결 { get; set; }
        public int 가위바위보 { get; set; }
        public int 계산25회 { get; set; }
        public int 고속세기 { get; set; }
        public int 기억5X5 { get; set; }
        public int 연속뺄셈 { get; set; }   
    }
}
