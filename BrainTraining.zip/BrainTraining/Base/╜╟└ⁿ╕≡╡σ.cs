﻿using BrainTraining.Data;
using BrainTraining.Test.가위바위보;
using BrainTraining.Test.순서연결;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 실전모드 : Form
    {
        public static bool realMode = false;
        public static List<RealModeRecord> realModeRecords;

        public 실전모드()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 메인화면().ShowDialog();
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            realMode = true;
            realModeRecords = new List<RealModeRecord>();
            int test1 = new Random().Next(1, 3);
            switch (test1)
            {
                case 1:
                    this.Hide();
                    new 순서연결준비().ShowDialog();
                    break;
                case 2:
                    this.Hide();
                    new 가위바위보준비().ShowDialog();
                    break;
            }
        }
    }
}
