﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 실전모드결과 : Form
    {
        public 실전모드결과()
        {
            InitializeComponent();

            int avgBrainAge = (실전모드.realModeRecords[0].age + 실전모드.realModeRecords[1].age + 실전모드.realModeRecords[2].age) / 3;
            
            로그인.record = new DataManager().LoadRecord();
            로그인.user = new DataManager().LoadUser();
            if (로그인.record.brainAge == 0) // 오늘 처음 테스트 할때만
            {
                로그인.record.brainAge = avgBrainAge;
                로그인.user.curBrainDate = 로그인.record.date;
                로그인.user.curBrain = avgBrainAge;
                new DataManager().SaveRecord();
                new DataManager().SaveUser();
            }

            label2.Text = avgBrainAge.ToString();

            label3.Text = 실전모드.realModeRecords[0].age.ToString();
            label4.Text = 실전모드.realModeRecords[1].age.ToString();
            label5.Text = 실전모드.realModeRecords[2].age.ToString();

            label10.Text = 실전모드.realModeRecords[0].testName + "("+ 실전모드.realModeRecords[0].record+")";
            label11.Text = 실전모드.realModeRecords[1].testName + "(" + 실전모드.realModeRecords[1].record + ")"; 
            label12.Text = 실전모드.realModeRecords[2].testName + "(" + 실전모드.realModeRecords[2].record + ")"; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            실전모드.realMode = false;
            this.Hide();
            new 메인화면().ShowDialog();
            Application.Exit();
        }
    }
}
