﻿using BrainTraining.Test.가위바위보;
using BrainTraining.Test.계산25회;
using BrainTraining.Test.고속세기;
using BrainTraining.Test.기억5X5;
using BrainTraining.Test.순서연결;
using BrainTraining.Test.연속뺄셈;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 선택모드 : Form
    {
        public 선택모드()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 메인화면().ShowDialog();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e) // 최고 숫자
        {
            this.Hide();
            new 최고숫자준비().ShowDialog();
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 순서연결준비().ShowDialog();
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 가위바위보준비().ShowDialog();
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 계산25회준비().ShowDialog();
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 고속세기준비().ShowDialog();
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 기억5X5준비().ShowDialog();
            Application.Exit();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 연속뺄셈준비().ShowDialog();
            Application.Exit();
        }
    }
}
