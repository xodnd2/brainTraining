﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 마이페이지 : Form
    {

        public 마이페이지()
        {
            InitializeComponent();
            로그인.user = new DataManager().LoadUser();
            label7.Text = 로그인.loginID;
            dateTimePicker1.Text = 로그인.user.birth;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 메인화면().ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dateTimePicker1.Text != 로그인.user.birth)
            {
                로그인.user.birth = dateTimePicker1.Text;
            }
            if (textBox2.Text == textBox3.Text)
            {
                로그인.user.pwd = textBox2.Text;
            }
            else
            {
                MessageBox.Show("비밀번호를 다시 확인해주세요.");
                this.Hide();
                new 마이페이지().ShowDialog();
            }
            new DataManager().SaveUser();
            MessageBox.Show("정보가 수정되었습니다.");
            this.Hide();
            new 메인화면().ShowDialog();
        }
    }
}
