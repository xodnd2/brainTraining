﻿using BrainTraining.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BrainTraining
{

    public partial class 로그인 : Form
    {
        public static string loginID;
        public static User user;
        public static Record record;
     
        public 로그인()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 회원가입().ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (new DataManager().Login(textBox1.Text, textBox2.Text) == textBox1.Text)
            {
                loginID = textBox1.Text;
                user = new DataManager().LoadUser();               
                if (user.curLoginDate != DateTime.Now.ToString("yyyy-MM-dd"))
                {
                    user.curLoginDate = DateTime.Now.ToString("yyyy-MM-dd");
                    new DataManager().SaveUser();
                    new DataManager().CreateTodayRecord();
                }
                record = new DataManager().LoadRecord();
                this.Hide();
                new 메인화면().ShowDialog();
            }
            else
                MessageBox.Show("아이디/비밀번호를 다시 확인해주세요.");
        }

        private void 로그인_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
