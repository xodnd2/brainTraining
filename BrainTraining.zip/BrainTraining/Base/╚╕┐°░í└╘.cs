﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 회원가입 : Form
    {
        public 회원가입()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 로그인().ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text == textBox3.Text)
                {
                    new DataManager().Register(textBox1.Text, textBox2.Text, dateTimePicker1.Text);
                    this.Hide();
                    new 로그인().ShowDialog();
                }
                else
                {
                    MessageBox.Show("비밀번호를 다시 확인해주세요.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("동일 id가 존재합니다.");
            }      
        }
    }
}
