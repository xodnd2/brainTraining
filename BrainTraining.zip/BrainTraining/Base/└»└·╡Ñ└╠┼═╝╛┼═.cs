﻿using BrainTraining.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrainTraining
{
    public partial class 유저데이터센터 : Form
    {
        List<RecordString> recordStrings = new DataManager().LoadAllUser();
        public 유저데이터센터()
        {
            InitializeComponent();
            dataGridView1.DataSource = recordStrings;
        }

        private void 유저데이터센터_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new 메인화면().ShowDialog();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (recordStrings.Exists(x => x.id == textBox1.Text))
                {                    
                    List<RecordString> searchedUser = new DataManager().SearchUser(textBox1.Text);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = searchedUser;
                }
                else
                {
                    MessageBox.Show("해당 유저가 존재하지 않습니다.");
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
